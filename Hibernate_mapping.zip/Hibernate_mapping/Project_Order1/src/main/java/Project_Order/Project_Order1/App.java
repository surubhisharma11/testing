package Project_Order.Project_Order1;

import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;



/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("persistence");
        EntityManager entityManager=entityManagerFactory.createEntityManager();
        
    	System.out.println( "Starting Transaction" ); 
    	entityManager.getTransaction().begin();
    	Product p=new Product();
    	
    	p.setName("Chetan Bhagat");
    	p.setPrice(500);
    	
    	Order or =new Order();
    	Date now = new Date();
        or.setPublished_Date(now);
        
        entityManager.persist(p);
     	or.setProduct(p);
     	System.out.println( "Saving Employee to Database" );
    	
     	entityManager.persist(or);
      	entityManager.getTransaction().commit();
    	
    	System.out.println("Generated Product " + p.getproduct_id());
    	System.out.println("Generated order " + or.getOrder_id());    
    
    	
    	
    
    	entityManager.close();
    	entityManagerFactory.close();
    	
     	
     	
     	
     }
    }
