package Project_Order.Project_Order1;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;



@Entity
@Table(name="Order")
public class Order {
	private int order_id;
	private Date Published_Date;
 private Product product;
 
 
 
 
 public Order(){}
 
public Order(Date publisher_id, Product product1) {
	super();
	Published_Date = publisher_id;
	this.product = product1;
}

@Id
@Column(name="order_id")
@GeneratedValue(strategy=GenerationType.AUTO, generator="my_entity_seq_gen")
@SequenceGenerator(name="my_entity_seq_gen", sequenceName="Book_seq",allocationSize=1)
public int getOrder_id() {
	return order_id;
}


public void setOrder_id(int order_id) {
	this.order_id = order_id;
}

@Column(name="Published_Date")
@Temporal(TemporalType.DATE)
public Date getPublished_Date() {
	return Published_Date;
}


public void setPublished_Date(Date published_Date) {
	Published_Date = published_Date;
}


@OneToOne(cascade=CascadeType.ALL)
@JoinColumn(name="product_id")
public Product getProduc1() {
	return product;
}


public void setProduct(Product product) {
	this.product = product;
}
 
 

	
	
	
}
