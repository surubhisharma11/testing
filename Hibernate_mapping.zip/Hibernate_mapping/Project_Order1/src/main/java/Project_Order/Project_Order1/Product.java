package Project_Order.Project_Order1;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="Product")
public class Product {
private int product_id;
private String name;
private int price;


public Product(){}

public Product( String name, int price) {
	super();

	this.name = name;
	this.price = price;
}

@Id
@Column(name="product_id")
@GeneratedValue(strategy=GenerationType.AUTO, generator="my_entity_seq_gen")
@SequenceGenerator(name="my_entity_seq_gen3", sequenceName="Author_seq",allocationSize=1)
public int getproduct_id() {
	return product_id;
}

public void setproduct_id(int Product_id) {
	product_id = Product_id;
}
@Column(name="name")
public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}
@Column(name="price")

public int getPrice() {
	return price;
}

public void setPrice(int price) {
	this.price = price;
}




}
