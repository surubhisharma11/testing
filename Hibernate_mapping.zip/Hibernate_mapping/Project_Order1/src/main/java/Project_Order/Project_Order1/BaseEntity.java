package Project_Order.Project_Order1;

public class BaseEntity {

}
