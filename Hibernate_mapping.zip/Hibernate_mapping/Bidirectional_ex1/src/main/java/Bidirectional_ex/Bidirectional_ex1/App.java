package Bidirectional_ex.Bidirectional_ex1;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        
    }
}
