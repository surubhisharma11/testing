package Books_Mapping.Books;

import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("persistence");
       EntityManager entityManager=entityManagerFactory.createEntityManager();
       
   	System.out.println( "Starting Transaction" ); 
   	entityManager.getTransaction().begin();
   	Author a=new Author();
   	a.setName("Chetan Bhagat");
   	a.setEmail("sadgdsa@gmail.com");
   	
   	Book b=new Book();
   	b.setTitle("JAVA");
   	b.setDescription("esgd rthtr");
   	Date now = new Date();
    b.setPublish_Date(now);
   	
	entityManager.persist(a);
	b.setAuthor(a);
	
 	System.out.println( "Saving Employee to Database" );
	entityManager.persist(b);
 	entityManager.getTransaction().commit();
	
   	System.out.println("Generated book " + b.getbid());
   	System.out.println("Generated Author " + a.getaid());
   	
   	
   	
   	
   
   	entityManager.close();
   	entityManagerFactory.close();
   	
    	
    	
    	
    }
}
