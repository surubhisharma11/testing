package Books_Mapping.Books;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="BOOK")
public class Book {

	private long bid;
	private String title;
	private String description;
	private Date publish_Date;
	private Author author;
	
	public Book(){}

	@Id
	@Column(name="bid")
	@GeneratedValue(strategy=GenerationType.AUTO, generator="my_entity_seq_gen")
	@SequenceGenerator(name="my_entity_seq_gen", sequenceName="Book_seq",allocationSize=1)


	public long getbid() {
		return bid;
	}

	@Override
	public String toString() {
		return "Book [bid=" + bid + ", title=" + title + ", description=" + description + ", publish_Date="
				+ publish_Date + ", author=" + author + "]";
	}

	public void setbid(long bid) {
		this.bid = bid;
	}
	@Column(name="title")
	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}
	@Column(name="description")
	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
	
	@Temporal(TemporalType.DATE)
	@Column(name="publish_Date")

	public Date getPublish_Date() {
		return publish_Date;
	}

	public void setPublish_Date(Date publish_Date) {
		this.publish_Date = publish_Date;
	}
	
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="aid")

	public Author getAuthor() {
		return author;
	}

	public void setAuthor(Author author) {
		this.author = author;
	}
	
	
	
	
	
}
