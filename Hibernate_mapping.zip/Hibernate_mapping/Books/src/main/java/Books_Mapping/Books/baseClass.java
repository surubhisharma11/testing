package Books_Mapping.Books;

import javax.persistence.Entity;
import javax.persistence.Table;


public class baseClass {
	
	
	
}
