package com.lti.Hibernate_Maven2.Books;



@Entity


public class Author {
	

}
