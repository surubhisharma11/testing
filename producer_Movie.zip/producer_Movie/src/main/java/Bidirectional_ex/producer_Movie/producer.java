package Bidirectional_ex.producer_Movie;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="producer")
public class producer {
	
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="pro-seq1")
	@SequenceGenerator(name="pro-seq1",sequenceName="seq_pro",allocationSize=1)
	@Column(name="P_id")
	private int p_id;
	
	@Column(name="PName")
	private String pName;
	
	@OneToMany(cascade=CascadeType.ALL)
	@JoinColumn(name="p_id")
	private Set<Movie> movies;

	public producer() {
		super();
	}

	public producer(String pName, Set<Movie> movies) {
		super();
		this.pName = pName;
		this.movies = movies;
	}

	public producer(int p_id, String pName, Set<Movie> movies) {
		super();
		this.p_id = p_id;
		this.pName = pName;
		this.movies = movies;
	}
	@Column(name="P_id")
	public int getP_id() {
		return p_id;
	}

	public void setP_id(int p_id) {
		this.p_id = p_id;
	}
	@Column(name="PNAME")
	public String getpName() {
		return pName;
	}

	public void setpName(String pName) {
		this.pName = pName;
	}
	public Set<Movie> getMovies() {
		return movies;
	}

	public void setMovies(Set<Movie> movies) {
		this.movies = movies;
	}


	
	
	

}
