package Bidirectional_ex.producer_Movie;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;


public class App 
{
    public static void main( String[] args )
    {
    	EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("persistence");
        EntityManager entityManager=entityManagerFactory.createEntityManager();
     	entityManager.getTransaction().begin();
      
        Movie m1=new Movie("DDLJ");
        Movie m2=new Movie("SOTY");
        Movie m3=new Movie("KKHH");
        Set <Movie> ms =new HashSet<Movie>();
        ms.add(m1);
     ms.add(m2);
     ms.add(m3);
     
        
        producer p=new producer("k Jo",ms);
        
       p.setMovies(ms);
       entityManager.persist(p);
       entityManager.getTransaction().commit();
   	   entityManager.close();
	   entityManagerFactory.close();
    }
}
