package Bidirectional_ex.producer_Movie;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="Movie")
public class Movie {
@Id
@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="mov-seq1")
@SequenceGenerator(name="mov-seq1",sequenceName="seq_pro",allocationSize=1)
@Column(name="id")
private int id;
@Column(name="movieName")
private String movieName;



public Movie( ) {
	super();
}
public Movie( String movieName) {
	super();
	
	this.movieName = movieName;
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getMovieName() {
	return movieName;
}
public void setMovieName(String movieName) {
	this.movieName = movieName;
}





}
