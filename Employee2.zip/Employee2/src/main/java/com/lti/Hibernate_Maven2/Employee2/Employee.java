package com.lti.Hibernate_Maven2.Employee2;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="employee")


public class Employee {
private int employeeId;
private String name;
private String branch;
@Id
@Column
@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="my_entity_seq_gen")
@SequenceGenerator(name="my_entity_seq_gen", sequenceName="MY_ENTITY_SEQ",allocationSize=1)

public int getEmployeeId(){
	
	return employeeId;
	
}
@Column(name="name")
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
@Column(name="branch")
public String getBranch() {
	return branch;
}
public void setBranch(String branch) {
	this.branch = branch;
}
public void setEmployeeId(int employeeId) {
	this.employeeId = employeeId;
}

@Override
public String toString() {
	return "Employee [employeeId=" + employeeId + ", name=" + name + ", branch=" + branch + "]";
}

}
