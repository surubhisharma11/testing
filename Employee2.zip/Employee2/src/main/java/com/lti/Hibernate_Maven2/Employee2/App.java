package com.lti.Hibernate_Maven2.Employee2;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.*;


public class App 
{
    public static void main( String[] args )
    {
    	EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("persistence");
       EntityManager entityManager=entityManagerFactory.createEntityManager();
       
   	System.out.println( "Starting Transaction" ); 
   	entityManager.getTransaction().begin();
   	Employee employee =new Employee();
   	//employee.setEmployeeId(2);
   	employee.setName("fff");
   	employee.setBranch("fdgfdfg");
   	System.out.println( "Saving Employee to Database" );
   	
   	entityManager.persist(employee);
   	entityManager.getTransaction().commit();
   	System.out.println("Generated Employee ID=" +employee.getEmployeeId());
   	
   	Employee emp=entityManager.find(Employee.class,employee.getEmployeeId());
   	System.out.println("got object "+emp.getName());
   	
   	@SuppressWarnings("unchecked")
   	List<Employee> listEmployee=entityManager.createQuery("Select e FROM Employee e").getResultList();
   	
   	if(listEmployee==null){
   		System.out.println( "No Employee Found" );
   	} else{
   		for(Employee emp1 : listEmployee){
   			System.out.println( "Employee name= " +emp1.getName() +", Employee id " +emp1.getEmployeeId()+",Employee Branch "+emp1.getBranch() );
   		}
   	}
   	
   	entityManager.close();
   	entityManagerFactory.close();
   	
    	
    	
    	
    }
}
